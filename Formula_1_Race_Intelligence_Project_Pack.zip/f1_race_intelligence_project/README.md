# Formula 1 Race Intelligence Analysis (Tableau)

## What this project contains
- A report-ready project proposal and implementation plan.
- CSV schema templates for the core Formula 1 tables.
- Tableau calculated-field recipes and dashboard specifications.
- A validation checklist for data quality and analytical limitations.

**Important:** The CSV files in `data_templates/` are empty schema templates, not real race data. Import verified historical CSVs before publishing results. Do not report calculated findings until the data has been loaded and checked.

## Suggested data source
A documented public dataset repository:
https://github.com/Bhushan-Alva/Formula-1

Use the repository's actual CSV files (commonly including `races.csv`, `results.csv`, `drivers.csv`, `constructors.csv`, `circuits.csv`, and `status.csv`). Confirm the current file names and schema in its README before importing.

## Study period
Choose the exact 17 seasons required by your instructor and apply the same date filter to every relevant worksheet. State the years explicitly in the final report. Do not claim a row count until you count the imported records.

## Tableau data model
Join/relate tables using keys:
- `races.raceId` -> `results.raceId`
- `results.driverId` -> `drivers.driverId`
- `results.constructorId` -> `constructors.constructorId`
- `races.circuitId` -> `circuits.circuitId`
- `results.statusId` -> `status.statusId`

Prefer Tableau relationships for tables at different levels of detail. Avoid joining lap-level or tyre-stint data directly to race-result rows without checking for row multiplication.

## Dashboard plan
1. Championship Performance: season trend of constructor points; driver points leaderboard; KPI cards.
2. Tyre Strategy: results by compound and circuit type (only if valid tyre stint data is available).
3. Global F1 Insights: race count by host country, driver nationality, podiums by driver/team.
4. Driver Reliability: finish vs retirement, retirement reasons, completion rate by season.
5. Tableau Story: introduce the question, show key charts, state findings and limitations.

## Tableau calculated fields
Create these fields after checking the imported column names.

### Race outcome category
IF CONTAINS(LOWER([status]), "collision") THEN "Collision"
ELSEIF CONTAINS(LOWER([status]), "engine") THEN "Engine"
ELSEIF CONTAINS(LOWER([status]), "brake") THEN "Brakes"
ELSEIF LOWER([status]) = "finished" OR CONTAINS(LOWER([status]), "+") THEN "Finished / classified"
ELSE "Other / verify"
END

This is a simple text-based grouping; manually review categories before drawing conclusions.

### Podium flag
IF INT([positionOrder]) <= 3 THEN 1 ELSE 0 END

If `positionOrder` is unavailable, use the dataset's verified finishing-position field, and ensure non-numeric codes are excluded.

### Finish flag
IF LOWER([status]) = "finished" OR CONTAINS(LOWER([status]), "+") THEN 1 ELSE 0 END

This rule may need adjustment to match the dataset's status definitions. Validate it against sample records.

### Completion rate
SUM([Finish flag]) / COUNTD([resultId])

Format as percentage. Use a unique race-result identifier and verify whether lapped/classified drivers count as finishers for your study.

### Constructor points
Use SUM([points]) at the race or season level. Confirm whether the dataset's points are race-level points or cumulative standings before using them.

## Visual encoding
- Line chart: Year on Columns, SUM(points) on Rows, constructor on Color.
- Driver leaderboard: driver on Rows, SUM(points) on Columns, sort descending.
- Host-country chart: country on Rows, COUNTD(raceId) on Columns.
- Podiums: driver/team on Rows, SUM(Podium flag) on Columns.
- Reliability: season on Columns, completion rate on Rows; retirement category on Color for stacked bars.
- Tyre strategy: compound on Columns, chosen outcome metric on Rows; only use if tyre data is available and linked at the right grain.

## Data-quality checklist
- Check row counts and duplicate primary keys.
- Replace source-specific missing-value tokens (for example `\\N`) with nulls.
- Parse dates and numeric columns correctly.
- Confirm relationships do not multiply result rows.
- Check that points are not double-counted after joins.
- Document the exact season range and excluded records.
- Check whether historical points systems differ by season.
- Keep race-result, lap-time, pit-stop and tyre-stint data at their correct grain.

## Final deliverables
- Tableau workbook (`.twb` or `.twbx`) created in Tableau.
- Cleaned CSV source files.
- This project report.
- Dashboard screenshots or a Tableau Public link.
- Short presentation covering objective, method, dashboard, findings and limitations.

## Scope note
The original brief mentions 6,464 records and 17 seasons. Treat these as target specifications until verified against the chosen source. Historical race-result tables do not automatically contain tyre compound, tyre stint, or detailed failure-cause data.
